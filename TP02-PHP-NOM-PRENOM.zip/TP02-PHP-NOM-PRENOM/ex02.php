<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Exercice 2</title>
</head>
<body>
    <h1>Exercice 2 : variables et concaténation</h1>
    <?php
    $nom = "Alaoui";
    $prenom = "Karim";
    $age = 20;
    $formation = "Licence Informatique";

    // Concaténation avec l'opérateur .
    $phrase = "Je m'appelle " . $prenom . " " . $nom . ", j'ai " . $age . " ans et je suis en " . $formation . ". ";
    // Ajout avec .=
    $phrase .= "J'apprends PHP.";
    echo "<p>$phrase</p>";

    // PHP est sensible à la casse : $note et $Note sont deux variables distinctes
    $note = 12;
    $Note = 16;
    echo "<p>\$note = $note</p>";
    echo "<p>\$Note = $Note</p>";
    ?>
    <p><a href="index.php">Retour à l'accueil</a></p>
</body>
</html>
